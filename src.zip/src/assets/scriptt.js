var a;
function MyFunctiodn() {
    if(a==1){

        $('.model-container').css('transform','scale(1)');

        return a=0;
    }
    else{
        $('.model-container').css('transform','scale(0)');
        return a=1;
    }

}

function ShowQuote() {
        document.getElementById("hederdown").style.display="block";
        document.getElementById("remove").style.display="block";
    document.getElementById("show").style.display="none";
    document.getElementById("contant").style.height="242px";
    document.getElementById("contant").style.paddingTop="68px";


}
