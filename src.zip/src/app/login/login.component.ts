import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  authemail=0;
  authpass=0;
  emailmsg="";
  authemaile=true;
  authpassworde=true;
constructor(private loginAuth:AuthService){}
ngOnInit(): void {

}

loginForm=new FormGroup({
  email:new FormControl('',[Validators.required, Validators.email]),
  pwd:new FormControl('',[
  Validators.required,
  Validators.minLength(2),
  Validators.maxLength(15)

  ]),
});
loginsubmited(){
  this.loginAuth.LoginUser([this.loginForm.value.email! ,this.loginForm.value.pwd!]).subscribe(res=>{
    if(res=='Successall'){
      window.location.href='todo';
    }
    else if(res=='failedpass'){
      this.authpassworde=false;
      this.authpass=1;
      this.authemail=0;
      this.authemaile=true;
    }
    else if(res=='Failedall')
      {
        this.authemail=1;
        this.authemaile=false;
        this.authpassworde=false;
        this.authpass=1;
      }
      else {
        this.authpassworde=true;
        this.authpass=0;
        this.authemail=1;
        this.authemaile=false;
      }

  });
}
get Email(): FormControl{
  return this.loginForm.get('email') as FormControl;
}

get PWD(): FormControl{
  return this.loginForm.get('pwd') as FormControl;
}
}


