import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) {   }
  baseServerUrl:string="https://localhost:7266/api/User/";

    LoginUser(loginInfo :Array<string>){
      return this.http.post(this.baseServerUrl +'login',{
      email:loginInfo[0],
      password:loginInfo[1]
    },{
      responseType: 'text',
    }
    );


}
}
