import { Todom } from './todom.model';

describe('Todom', () => {
  it('should create an instance', () => {
    expect(new Todom()).toBeTruthy();
  });
});
