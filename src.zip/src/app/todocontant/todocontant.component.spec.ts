import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TodocontantComponent } from './todocontant.component';

describe('TodocontantComponent', () => {
  let component: TodocontantComponent;
  let fixture: ComponentFixture<TodocontantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodocontantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TodocontantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
