import { Component, OnInit } from '@angular/core';
import { TodosService } from '../todos.service';

@Component({
  selector: 'app-todocontant',
  templateUrl: './todocontant.component.html',
  styleUrls: ['./todocontant.component.css'],

})
export class TodocontantComponent implements OnInit {

searchText:any;

  ngOnInit() {
    this.service.getAllTodo();
  }
  constructor(public service:TodosService){

  }


  getBackgroundColor(status:String) {
if(status.includes('High')){
  return '#DC3545';
}
else if(status.includes('Low')){
  return '#39AC95';

}
else if(status.includes('Medium')){
  return '#FE913E';

}
else{
  return '#212529';
}
  }

  isScale:boolean=false;
  additem:boolean=false;
  quote='n';
toggle(){
this.isScale=!this.isScale;
}
item(){
  this.additem=!this.additem;
}
show(){
  this.quote='y';
}
hide(){
  this.quote='n';
}
}
