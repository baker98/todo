import { Injectable } from '@angular/core';
import { Todom } from './todom.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TodosService {
url:string="https://localhost:7266/api/todo/GetAllTodo";
  todos: Todom[] = [];

  constructor(private http:HttpClient) { }
  getAllTodo(){
    this.http.get(this.url).toPromise().then(
      res=>{
        this.todos=res as Todom[];
      }
    )
  }
}

