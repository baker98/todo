
export class Todom {
  id:number=1;
  title:string='';
  categorie:string='';
  duedate:string='';
  estimate:string='';
  importance:string='';
  status:number=55;

}
